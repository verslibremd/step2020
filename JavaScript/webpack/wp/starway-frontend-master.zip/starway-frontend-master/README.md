# Webpack 4 Configuration


### Запуск сборки ###

- `npm run serve` – запускает dev сервер для разработки
- `npm run build` – собирает файлы для продакшена
